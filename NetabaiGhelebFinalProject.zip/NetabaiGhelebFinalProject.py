"""
Program: NetabaiGhelebFinalProject.py
Author: Gheleb Netabai
Last date modified: 5/11/23
The purpose of this program is serve as a simulated sheet generation tool when creating new characters for Dungeons and Dragons 5e. It allows the manual input of character aspects such as Name, class, background, etc; as well as includes a calculator for manual and random/dice stat generation and character picture input functionality. The program can also generate a pdf copy of the finalized character sheet information.
"""

import tkinter as tk
from tkinter import filedialog
from tkinter.scrolledtext import ScrolledText
import random
import math
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from PIL import Image, ImageTk

# create a new tkinter window
root = tk.Tk()

def start_screen():
    # set the window title and size
    root.title("D&D 5e Character Sheet Creator")
    root.geometry("1000x750")

    # create a label widget with the title text and pack it at the top of the window
    title_label = tk.Label(root, text="D&D 5e Character Sheet Creator", font=("Arial", 24, "bold"))
    title_label.pack(side="top", pady=20)

    # create a label widget with the version information and pack it at the bottom-left corner of the window
    version_label = tk.Label(root, text="v. 1.0.0 - 5/11/13 - by Gheleb Netabai", font=("Arial", 10, "italic"))
    version_label.pack(side="left", anchor="sw", padx=20, pady=20)

    # center the window at the top of the screen
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    x = (screen_width - 1000) // 2
    y = 0
    root.geometry("+{}+{}".format(x, y))

    # create a label widget for character name
    char_name_label = tk.Label(root, text="Character Name", font=("Arial", 10, "italic"))

    # create a text input box widget for character name
    char_name_input = tk.Entry(root, font=("Arial", 12))

    # place the character name label and text input box
    char_name_label.place(x=78, y=165)
    char_name_input.place(x=78, y=143, width=200)

    # create a label widget for alignment
    alignment_label = tk.Label(root, text="Alignment", font=("Arial", 10, "italic"))

    # create a dropdown widget for alignment
    alignment_options = ["Lawful Good", "Lawful Neutral", "Lawful Evil", "Neutral Good", "True Neutral", "Neutral Evil", "Chaotic Good", "Chaotic Neutral", "Chaotic Evil"]
    alignment_var = tk.StringVar(root)
    alignment_var.set(alignment_options[0])
    alignment_dropdown = tk.OptionMenu(root, alignment_var, *alignment_options)
    alignment_dropdown.config(font=("Arial", 12), width=18, anchor="w")

    # place the alignment label and dropdown
    alignment_label.place(x=290, y=175)
    alignment_dropdown.place(x=290, y=143, width=200)

    # create a label widget for race
    race_label = tk.Label(root, text="Race", font=("Arial", 10, "italic"))

    # create a text input box widget for race
    race_input = tk.Entry(root, font=("Arial", 12))

    # place the race label and text input box
    race_label.place(x=78, y=217)
    race_input.place(x=78, y=195, width=200)

    # create a label widget for class
    class_label = tk.Label(root, text="Class", font=("Arial", 10, "italic"))

    # create a text input box widget for class
    class_input = tk.Entry(root, font=("Arial", 12))

    # place the class label and text input box
    class_label.place(x=78, y=269)
    class_input.place(x=78, y=247, width=200)

    # create a label widget for background
    background_label = tk.Label(root, text="Background", font=("Arial", 10, "italic"))

    # create a text input box widget for background
    background_input = tk.Entry(root, font=("Arial", 12))

    # place the background label and text input box
    background_label.place(x=78, y=321)
    background_input.place(x=78, y=299, width=200)

    # create a "Generate Stats" button widget
    generate_stats_button = tk.Button(root, text="Generate Stats", font=("Arial", 12), command=generate_stats)

    # place the "Generate Stats" button widget
    generate_stats_button.place(x=78, y=350, width=200)

def generate_stats():
    # assign global variables
    global char_name
    global alignment
    global race
    global class_type
    global background
    global feats
    global notes
    global file_path
    file_path = "" # assigning empty value to file_path variable for future pathing resolution in pdf generation

    # Save the current values in the input boxes and dropdown to their respective variables
    char_name = char_name_input.get()
    alignment = alignment_var.get()
    race = race_input.get()
    class_type = class_input.get()
    background = background_input.get()
    feats = feats_input.get('1.0', 'end-1c')
    notes = notes_input.get('1.0', 'end-1c')

    # Destroy all widgets currently in the tkinter window
    root.withdraw()

    # create a new tkinter window
    statPage = tk.Tk()
    statPage.title("D&D 5e Character Sheet Creator")
    statPage.geometry("1000x750")

    # Create a new label widget with the program title and pack it at the top of the window
    title_label = tk.Label(statPage, text="D&D 5e Character Sheet Creator", font=("Arial", 24, "bold"))
    title_label.pack(side="top", pady=20)

    # Create a label widget with the version information and pack it at the bottom-left corner of the window
    version_label = tk.Label(statPage, text="v. 1.0.0 - 5/11/13 - by Gheleb Netabai", font=("Arial", 10, "italic"))
    version_label.pack(side="left", anchor="sw", padx=20, pady=20)

    # Center the window at the top of the screen
    screen_width = statPage.winfo_screenwidth()
    screen_height = statPage.winfo_screenheight()
    x = (screen_width - 1000) // 2
    y = 0
    statPage.geometry("+{}+{}".format(x, y))

    # Destroy all the stat page window and return the root window
    def back_window():
        statPage.destroy()
        root.deiconify()
    
    # create a "Back" button widget
    back_button = tk.Button(statPage, text="Back", font=("Arial", 12), command=back_window)

    # place the "Back" button widget
    back_button.place(x=78, y=350, width=200)

    # create and store character stats as variables, update stat total and modifier counts
    def record_stats():
        global strength
        global dexterity
        global constitution
        global intelligence
        global wisdom
        global charisma
        global strMod
        global dexMod
        global conMod
        global intMod
        global wisMod
        global chaMod

        strength = int(str_spinbox.get())
        strMod = math.floor((strength - 10)//2)
        str_total.config(text=str(strength))
        if strMod >= 0:
            str_mod.config(text="+"+str(strMod))
        else:
            str_mod.config(text=str(strMod))

        dexterity = int(dex_spinbox.get())
        dexMod = math.floor((dexterity - 10)//2)
        dex_total.config(text=str(dexterity))
        if dexMod >= 0:
            dex_mod.config(text="+"+str(dexMod))
        else:
            dex_mod.config(text=str(dexMod))

        constitution = int(con_spinbox.get())
        conMod = math.floor((constitution - 10)//2)
        con_total.config(text=str(constitution))
        if conMod >= 0:
            con_mod.config(text="+"+str(conMod))
        else:
            con_mod.config(text=str(conMod))

        intelligence = int(int_spinbox.get())
        intMod = math.floor((intelligence - 10)//2)
        int_total.config(text=str(intelligence))
        if intMod >= 0:
            int_mod.config(text="+"+str(intMod))
        else:
            int_mod.config(text=str(intMod))

        wisdom = int(wis_spinbox.get())
        wisMod = math.floor((wisdom - 10)//2)
        wis_total.config(text=str(wisdom))
        if wisMod >= 0:
            wis_mod.config(text="+"+str(wisMod))
        else:
            wis_mod.config(text=str(wisMod))

        charisma = int(cha_spinbox.get())
        chaMod = math.floor((charisma - 10)//2)
        cha_total.config(text=str(charisma))
        if chaMod >= 0:
            cha_mod.config(text="+"+str(chaMod))
        else:
            cha_mod.config(text=str(chaMod))

    # create and label stat spinboxes with range of 0-99 for each character stat
    str_spinbox = tk.Spinbox(statPage, from_=0, to=20, width=2, command=record_stats)
    str_spinbox.place(x=120, y=165)
    str_label = tk.Label(statPage, text="STR:", font=("Arial", 10, "bold"))
    str_label.place(x=78, y=165)
    str_spinbox.delete(0,"end")
    str_spinbox.insert(0,10)

    dex_spinbox = tk.Spinbox(statPage, from_=0, to=20, width=2, command=record_stats)
    dex_spinbox.place(x=120, y=190)
    dex_label = tk.Label(statPage, text="DEX:", font=("Arial", 10, "bold"))
    dex_label.place(x=78, y=190)
    dex_spinbox.delete(0,"end")
    dex_spinbox.insert(0,10)

    con_spinbox = tk.Spinbox(statPage, from_=0, to=20, width=2, command=record_stats)
    con_spinbox.place(x=120, y=215)
    con_label = tk.Label(statPage, text="CON:", font=("Arial", 10, "bold"))
    con_label.place(x=78, y=215)
    con_spinbox.delete(0,"end")
    con_spinbox.insert(0,10)

    int_spinbox = tk.Spinbox(statPage, from_=0, to=20, width=2, command=record_stats)
    int_spinbox.place(x=120, y=240)
    int_label = tk.Label(statPage, text="INT:", font=("Arial", 10, "bold"))
    int_label.place(x=78, y=240)
    int_spinbox.delete(0,"end")
    int_spinbox.insert(0,10)

    wis_spinbox = tk.Spinbox(statPage, from_=0, to=20, width=2, command=record_stats)
    wis_spinbox.place(x=120, y=265)
    wis_label = tk.Label(statPage, text="WIS:", font=("Arial", 10, "bold"))
    wis_label.place(x=78, y=265)
    wis_spinbox.delete(0,"end")
    wis_spinbox.insert(0,10)

    cha_spinbox = tk.Spinbox(statPage, from_=0, to=20, width=2, command=record_stats)
    cha_spinbox.place(x=120, y=290)
    cha_label = tk.Label(statPage, text="CHA:", font=("Arial", 10, "bold"))
    cha_label.place(x=78, y=290)
    cha_spinbox.delete(0,"end")
    cha_spinbox.insert(0,10)

    # create a label to display stat totals and modifiers
    total_header = tk.Label(statPage, text="Total", font=("Arial", 10, "bold", "underline"))
    total_header.place(x=162, y=144)
    mod_header = tk.Label(statPage, text="Modifier", font=("Arial", 10, "bold", "underline"))
    mod_header.place(x=210, y=144)

    str_total = tk.Label(statPage, text="10", font=("Arial", 10, "bold"))
    str_total.place(x=173, y=164)
    str_mod = tk.Label(statPage, text=("+0"), font=("Arial", 10, "bold"))
    str_mod.place(x=225, y=164)
    
    dex_total = tk.Label(statPage, text="10", font=("Arial", 10, "bold"))
    dex_total.place(x=173, y=189)
    dex_mod = tk.Label(statPage, text="+0", font=("Arial", 10, "bold"))
    dex_mod.place(x=225, y=189)

    con_total = tk.Label(statPage, text="10", font=("Arial", 10, "bold"))
    con_total.place(x=173, y=214)
    con_mod = tk.Label(statPage, text="+0", font=("Arial", 10, "bold"))
    con_mod.place(x=225, y=214)

    int_total = tk.Label(statPage, text="10", font=("Arial", 10, "bold"))
    int_total.place(x=173, y=239)
    int_mod = tk.Label(statPage, text="+0", font=("Arial", 10, "bold"))
    int_mod.place(x=225, y=239)

    wis_total = tk.Label(statPage, text="10", font=("Arial", 10, "bold"))
    wis_total.place(x=173, y=264)
    wis_mod = tk.Label(statPage, text="+0", font=("Arial", 10, "bold"))
    wis_mod.place(x=225, y=264)

    cha_total = tk.Label(statPage, text="10", font=("Arial", 10, "bold"))
    cha_total.place(x=173, y=289)
    cha_mod = tk.Label(statPage, text="+0", font=("Arial", 10, "bold"))
    cha_mod.place(x=225, y=289)

    # create a function for rolling a D&D stat randomly, taking the sum of all rolls after removing the lowest
    def roll_dice_discarding_lowest(n_dice, dice_rank):
        results = [  # Generate n_dice numbers between [1, dice_rank]
            random.randint(1, dice_rank)
            for n
            in range(n_dice)
        ]
        lowest = min(results)  # Find the lowest roll among the results
        results.remove(lowest)  # Remove the first instance of that lowest roll
        return sum(results)  # Return the sum of the remaining results.

    # create function to assign stats randomly
    def roll_stats():
        global strength
        global dexterity
        global constitution
        global intelligence
        global wisdom
        global charisma

        strength = roll_dice_discarding_lowest(4, 6)
        strMod = math.floor((strength - 10)//2)
        str_total.config(text=str(strength))
        if strMod >= 0:
            str_mod.config(text="+"+str(strMod))
        else:
            str_mod.config(text=str(strMod))
        str_spinbox.delete(0,"end")
        str_spinbox.insert(0,strength)

        dexterity = roll_dice_discarding_lowest(4, 6)
        dexMod = math.floor((dexterity - 10)//2)
        dex_total.config(text=str(dexterity))
        if dexMod >= 0:
            dex_mod.config(text="+"+str(dexMod))
        else:
            dex_mod.config(text=str(dexMod))
        dex_spinbox.delete(0,"end")
        dex_spinbox.insert(0,dexterity)

        constitution = roll_dice_discarding_lowest(4, 6)
        conMod = math.floor((constitution - 10)//2)
        con_total.config(text=str(constitution))
        if conMod >= 0:
            con_mod.config(text="+"+str(conMod))
        else:
            con_mod.config(text=str(conMod))
        con_spinbox.delete(0,"end")
        con_spinbox.insert(0,constitution)

        intelligence = roll_dice_discarding_lowest(4, 6)
        intMod = math.floor((intelligence - 10)//2)
        int_total.config(text=str(intelligence))
        if intMod >= 0:
            int_mod.config(text="+"+str(intMod))
        else:
            int_mod.config(text=str(intMod))
        int_spinbox.delete(0,"end")
        int_spinbox.insert(0,intelligence)

        wisdom = roll_dice_discarding_lowest(4, 6)
        wisMod = math.floor((wisdom - 10)//2)
        wis_total.config(text=str(wisdom))
        if wisMod >= 0:
            wis_mod.config(text="+"+str(wisMod))
        else:
            wis_mod.config(text=str(wisMod))
        wis_spinbox.delete(0,"end")
        wis_spinbox.insert(0,wisdom)

        charisma = roll_dice_discarding_lowest(4, 6)
        chaMod = math.floor((charisma - 10)//2)
        cha_total.config(text=str(charisma))
        if chaMod >= 0:
            cha_mod.config(text="+"+str(chaMod))
        else:
            cha_mod.config(text=str(chaMod))
        cha_spinbox.delete(0,"end")
        cha_spinbox.insert(0,charisma)

    # create button to randomly generate stats
    roll_button = tk.Button(statPage, text="Randomly Roll Stats", font=("Arial", 12), command=roll_stats)

    # place the "Randomly Roll Stats" button widget
    roll_button.place(x=78, y=100, width=200)

    # Create the button to import character profile photo/logos
    def open_file():
        global img
        global file_path
        file_path = filedialog.askopenfilename()
        img = Image.open(file_path)
        img = img.resize((300, 300), Image.LANCZOS) # resize imported image to 300 x 300 format via LANCZOS algorithm
        photo = ImageTk.PhotoImage(img, master = pic_display)
        pic_display.image = photo
        pic_display.config(image=photo)

    # Create the button to import character profile photo/logos and display box
    image_button = tk.Button(statPage, text="Import Profile Picture/Logo", command=open_file)
    image_button.place(x=500, y=100, width=200)

    # Create label to hold and display imported photo/logo
    pic_display = tk.Label(statPage)
    pic_display.place(x=500, y=150)

    def export_character_sheet():
        # Create a PDF file and add the character data to it
        character_sheet = canvas.Canvas("dnd_character_sheet.pdf", pagesize=letter)
        character_sheet.drawString(100, 750, "Name: ")
        if char_name != "": # check for whether input space is left blank or not
            character_sheet.drawString(140, 750, char_name)
        else:
            character_sheet.drawString(140, 750, "<NO NAME ENTERED>")
        character_sheet.drawString(100, 730, "Alignment: " + alignment)
        character_sheet.drawString(100, 710, "Race: ")
        if race != "": # check for whether input space is left blank or not
            character_sheet.drawString(140, 710, race)
        else:
            character_sheet.drawString(140, 710, "<NO RACE ENTERED>")
        character_sheet.drawString(100, 690, "Class: ")
        if class_type != "": # check for whether input space is left blank or not
            character_sheet.drawString(140, 690, class_type)
        else:
            character_sheet.drawString(140, 690, "<NO CLASS ENTERED>")
        character_sheet.drawString(100, 670, "Background: ")
        if background != "": # check for whether input space is left blank or not
            character_sheet.drawString(175, 670, background)
        else:
            character_sheet.drawString(175, 670, "<NO BACKGROUND ENTERED>")
        # creates pdf generation for character stat tree
        character_sheet.drawString(20, 750, "STATS")
        character_sheet.drawString(20, 730, "STR: " + str(strength))
        character_sheet.drawString(20, 710, "DEX: " + str(dexterity))
        character_sheet.drawString(20, 690, "CON: " + str(constitution))
        character_sheet.drawString(20, 670, "INT: " + str(intelligence))
        character_sheet.drawString(20, 650, "WIS: " + str(wisdom))
        character_sheet.drawString(20, 630, "CHA: " + str(charisma))
        if feats != "": # check for whether input space is left blank or not
            character_sheet.drawString(100, 650, "Feats/Abilities: ")
            character_sheet.drawString(185, 650, feats)
        if notes != "": # check for whether input space is left blank or not
            character_sheet.drawString(100, 600, "Character Notes: ")
            character_sheet.drawString(185, 600, notes)
        if file_path != "": # check for whether profile/logo image has been uploaded to the character sheet
            character_sheet.drawImage(file_path, 435, 690, width = 100, height = 100)
        character_sheet.save()

        # Open the PDF file with the default PDF viewer
        import os
        os.system("start dnd_character_sheet.pdf")
    
    # Create the button to export the filled out character sheet data
    export_button = tk.Button(statPage, text="Export Character Sheet", font=("Arial", 12), command=export_character_sheet)
    export_button.place(x=78, y=400, width=200)

    # run the tkinter event loop
    statPage.mainloop()


# set the window title and size
root.title("D&D 5e Character Sheet Creator")
root.geometry("1000x550")

# create a label widget with the title text and pack it at the top of the window
title_label = tk.Label(root, text="D&D 5e Character Sheet Creator", font=("Arial", 24, "bold"))
title_label.pack(side="top", pady=20)

# create a label frame to hold and display D&D logo image
logo = ImageTk.PhotoImage(Image.open("5eLogo.png"))
logo_frame = tk.Label(root, text="D&D 5E logo", image = logo)
logo_frame.place(x=100, y=20)
logo2 = ImageTk.PhotoImage(Image.open("5eLogo.png"))
logo_frame2 = tk.Label(root, text="D&D 5E logo", image = logo)
logo_frame2.place(x=800, y=20)

# create a label widget with the version information and pack it at the bottom-left corner of the window
version_label = tk.Label(root, text="v. 1.0.0 - 5/11/13 - by Gheleb Netabai", font=("Arial", 10, "italic"))
version_label.pack(side="left", anchor="sw", padx=20, pady=20)

# center the window at the top of the screen
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = (screen_width - 1000) // 2
y = 0
root.geometry("+{}+{}".format(x, y))

# create a label widget for character name
char_name_label = tk.Label(root, text="Character Name", font=("Arial", 10, "italic"))

# create a text input box widget for character name
char_name_input = tk.Entry(root, font=("Arial", 12))

# place the character name label and text input box
char_name_label.place(x=78, y=165)
char_name_input.place(x=78, y=143, width=200)

# create a label widget for alignment
alignment_label = tk.Label(root, text="Alignment", font=("Arial", 10, "italic"))

# create a dropdown widget for alignment
alignment_options = ["Lawful Good", "Lawful Neutral", "Lawful Evil", "Neutral Good", "True Neutral", "Neutral Evil", "Chaotic Good", "Chaotic Neutral", "Chaotic Evil"]
alignment_var = tk.StringVar(root)
alignment_var.set(alignment_options[0])
alignment_dropdown = tk.OptionMenu(root, alignment_var, *alignment_options)
alignment_dropdown.config(font=("Arial", 12), width=18, anchor="w")

# place the alignment label and dropdown
alignment_label.place(x=290, y=175)
alignment_dropdown.place(x=290, y=143, width=200)

# create a label widget for race
race_label = tk.Label(root, text="Race", font=("Arial", 10, "italic"))

# create a text input box widget for race
race_input = tk.Entry(root, font=("Arial", 12))

# place the race label and text input box
race_label.place(x=78, y=217)
race_input.place(x=78, y=195, width=200)

# create a label widget for class
class_label = tk.Label(root, text="Class", font=("Arial", 10, "italic"))

# create a text input box widget for class
class_input = tk.Entry(root, font=("Arial", 12))

# place the class label and text input box
class_label.place(x=78, y=269)
class_input.place(x=78, y=247, width=200)

# create a label widget for background
background_label = tk.Label(root, text="Background", font=("Arial", 10, "italic"))

# create a text input box widget for background
background_input = tk.Entry(root, font=("Arial", 12))

# place the background label and text input box
background_label.place(x=78, y=321)
background_input.place(x=78, y=299, width=200)

# create a label widget for Feats/Abilities
feats_label = tk.Label(root, text="Feats/Abilities", font=("Arial", 10, "italic"))

# create a scrolling text input box widget for feats/abilities
feats_input = ScrolledText(root, font=("Arial", 10), wrap=tk.WORD, height = 10)

# place the feats/abilities label and text input box
feats_label.place(x=500, y=140)
feats_input.place(x=500, y=160, width=450)

# create a label widget for Character Notes
notes_label = tk.Label(root, text="Character Notes", font=("Arial", 10, "italic"))

# create a scrolling text input box widget for Character Notes
notes_input = ScrolledText(root, font=("Arial", 10), wrap=tk.WORD, height = 10)

# place the character notes label and text input box
notes_label.place(x=500, y=330)
notes_input.place(x=500, y=350, width=450)

# create a "Generate Stats" button widget
generate_stats_button = tk.Button(root, text="Generate Stats", font=("Arial", 12), command=generate_stats)

# place the "Generate Stats" button widget
generate_stats_button.place(x=78, y=350, width=200)

# run the tkinter event loop
root.mainloop()
